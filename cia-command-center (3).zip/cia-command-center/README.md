# CIA Command Center

Panel privado en español para una escuadra: login cerrado, directorio, rangos, operaciones, comunicados con ventana emergente al iniciar sesión y administración. React + Vite + Supabase.

## Importante
Este paquete es una base funcional para desplegar, no una web ya publicada. Necesitas tu propio proyecto Supabase y Vercel. No hay credenciales de administrador preconfiguradas. El acceso público de registro no se muestra en la interfaz.

## 1. Crear Supabase
1. Crea un proyecto en https://supabase.com/dashboard (región Europa recomendada).
2. Abre **SQL Editor → New query**, pega el contenido de `supabase/migrations/001_initial.sql` y ejecútalo.
3. En **Authentication → Providers → Email**, deja el proveedor Email activado. La web no expone registro público; las cuentas las crea una función administrativa.
4. Copia la Project URL y la publishable/anon key desde **Project Settings → API**. No compartas ni publiques la `service_role` key.

## 2. Crear el primer superadmin (solo una vez)
La función de creación de usuarios exige un superadmin, por lo que el primero debe crearse mediante una operación controlada:
1. En Supabase → Authentication → Users, crea manualmente tu usuario con tu propio correo y una contraseña fuerte.
2. Copia el UUID de ese usuario.
3. En SQL Editor ejecuta lo siguiente sustituyendo `UUID_DEL_USUARIO` y `TU_NOMBRE` por valores propios:

```sql
insert into public.profiles (id, username, rank, active)
values ('UUID_DEL_USUARIO', 'TU_NOMBRE', 'superadmin', true);
```

No pongas credenciales reales en este archivo ni las envíes por chat. Este paso debe hacerlo únicamente el propietario de confianza del proyecto.

## 3. Desplegar la función segura de creación de cuentas
Instala Supabase CLI y Docker según la documentación oficial: https://supabase.com/docs/guides/cli. Desde la carpeta del proyecto:

```bash
supabase login
supabase link --project-ref TU_PROJECT_REF
supabase functions deploy admin-create-user
```

Las funciones alojadas reciben `SUPABASE_URL`, `SUPABASE_ANON_KEY` y `SUPABASE_SERVICE_ROLE_KEY` como secretos administrados por Supabase. No pongas la service role key en variables `VITE_` ni en código del navegador. Configura `ALLOWED_ORIGIN` con el dominio exacto de la web si quieres restringir CORS.

## 4. Ejecutar localmente
Necesitas Node.js LTS.

```bash
npm install
cp .env.example .env.local
```

Edita `.env.local` y completa `VITE_SUPABASE_URL` y `VITE_SUPABASE_ANON_KEY` con la URL y la clave publicable/anon de tu proyecto. Luego:

```bash
npm run dev
```

## 5. Publicar en Vercel
1. Sube esta carpeta a un repositorio privado en GitHub.
2. Importa el repositorio desde https://vercel.com/.
3. Añade las variables `VITE_SUPABASE_URL` y `VITE_SUPABASE_ANON_KEY` en Vercel y despliega.
4. En Supabase configura los dominios de redirect permitidos para el dominio de Vercel.

## Avisos emergentes
Los administradores y superadministradores pueden publicar avisos desde la pestaña **Comunicados**. Al iniciar sesión, cada miembro verá el comunicado más reciente en una ventana modal superpuesta antes de continuar; al pulsar «Entendido», podrá usar el panel. Los avisos se guardan en Supabase y se comparten entre las cuentas autorizadas.

## Seguridad / limitaciones a revisar antes de usar con miembros reales
- La RLS es obligatoria y se activa en todas las tablas de la migración.
- La clave `service_role` solo debe estar en el entorno de funciones de confianza.
- Las contraseñas iniciales se comunican por un canal privado y deben ser únicas; la UI no las almacena en la base de datos.
- El primer superadmin se crea manualmente; nunca habilites un formulario público para asignar rangos.
- Antes de producción, prueba políticas RLS con cuentas de cada rango y activa protección contra contraseñas filtradas/limitación de tasa si tu plan lo permite.
- Este starter no incluye todavía cambio forzoso de contraseña al primer inicio, recuperación de contraseña, invitaciones por email ni borrado definitivo de usuarios desde el panel. Desactivar una cuenta bloquea su acceso a las tablas, pero para revocar también una sesión existente, elimina la sesión/usuario desde el panel de Supabase o añade revocación en la función administrativa.

## Documentación
- Supabase Auth: https://supabase.com/docs/guides/auth
- Supabase Edge Functions: https://supabase.com/docs/guides/functions
- Vercel: https://vercel.com/docs
