-- CIA Command Center: ejecutar en Supabase SQL Editor.
create type public.member_rank as enum ('superadmin','admin','oficial','soldado');
create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text not null unique check (char_length(username) between 2 and 32),
 rank public.member_rank not null default 'soldado',
 active boolean not null default true,
 created_at timestamptz not null default now()
);
create table public.operations (
 id uuid primary key default gen_random_uuid(), title text not null check(char_length(title) between 1 and 120),
 description text not null default '', status text not null default 'Planificación' check(status in ('Planificación','En curso','Completada','Cancelada')),
 created_by uuid not null references public.profiles(id), created_at timestamptz not null default now()
);
create table public.announcements (
 id uuid primary key default gen_random_uuid(), body text not null check(char_length(body) between 1 and 3000),
 created_by uuid not null references public.profiles(id), created_at timestamptz not null default now()
);
create table public.activity_logs (
 id bigint generated always as identity primary key, actor_id uuid references public.profiles(id) on delete set null,
 action text not null, created_at timestamptz not null default now()
);
create index operations_created_at_idx on public.operations(created_at desc);
create index announcements_created_at_idx on public.announcements(created_at desc);
create index logs_created_at_idx on public.activity_logs(created_at desc);
create or replace function public.my_rank() returns public.member_rank language sql stable security definer set search_path=public as $$ select rank from public.profiles where id=auth.uid() and active=true $$;
create or replace function public.is_active_member() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.profiles where id=auth.uid() and active=true) $$;
revoke all on function public.my_rank() from public;
revoke all on function public.is_active_member() from public;
grant execute on function public.my_rank() to authenticated;
grant execute on function public.is_active_member() to authenticated;
-- Prevent a user from editing their own role or active flag, even via direct API calls.
create or replace function public.protect_profile_privileges() returns trigger language plpgsql security definer set search_path=public as $$
begin
 if auth.uid() is not null and auth.uid() = old.id then
   if new.rank is distinct from old.rank or new.active is distinct from old.active then raise exception 'No puedes cambiar tus propios privilegios'; end if;
 end if;
 if auth.uid() is not null and auth.uid() <> old.id and public.my_rank() <> 'superadmin' then
   if new.rank is distinct from old.rank then raise exception 'Solo superadmin puede cambiar rangos'; end if;
 end if;
 return new;
end; $$;
create trigger protect_profile_privileges before update on public.profiles for each row execute function public.protect_profile_privileges();
alter table public.profiles enable row level security;
alter table public.operations enable row level security;
alter table public.announcements enable row level security;
alter table public.activity_logs enable row level security;
create policy "Active members read profiles" on public.profiles for select to authenticated using (public.is_active_member());
create policy "Admins update member activation" on public.profiles for update to authenticated using (public.my_rank() in ('superadmin','admin')) with check (public.is_active_member());
create policy "Members read operations" on public.operations for select to authenticated using (public.is_active_member());
create policy "Admins manage operations" on public.operations for insert to authenticated with check (public.my_rank() in ('superadmin','admin') and created_by=auth.uid());
create policy "Admins update operations" on public.operations for update to authenticated using (public.my_rank() in ('superadmin','admin')) with check (public.my_rank() in ('superadmin','admin'));
create policy "Members read announcements" on public.announcements for select to authenticated using (public.is_active_member());
create policy "Admins publish announcements" on public.announcements for insert to authenticated with check (public.my_rank() in ('superadmin','admin') and created_by=auth.uid());
create policy "Admins read activity logs" on public.activity_logs for select to authenticated using (public.my_rank() in ('superadmin','admin'));
-- Logs are inserted only by trusted server-side code, not by browser clients.
revoke insert, update, delete on public.activity_logs from anon, authenticated;
revoke insert, delete on public.profiles from anon, authenticated;
grant select on public.profiles, public.operations, public.announcements to authenticated;
grant update (active) on public.profiles to authenticated;
grant insert, update on public.operations to authenticated;
grant insert on public.announcements to authenticated;
grant select on public.activity_logs to authenticated;
-- New auth users do NOT automatically receive a profile. Only the trusted admin Edge Function creates accounts/profiles.
grant update (rank, active) on public.profiles to authenticated;
