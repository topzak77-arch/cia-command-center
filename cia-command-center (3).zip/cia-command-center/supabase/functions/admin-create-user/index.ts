import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';
const allowedRanks = ['superadmin','admin','oficial','soldado'];
Deno.serve(async (req) => {
 if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
 if (req.method !== 'POST') return new Response(JSON.stringify({error:'Method not allowed'}), {status:405,headers:{...corsHeaders,'Content-Type':'application/json'}});
 try {
  const authHeader=req.headers.get('Authorization');
  if(!authHeader?.startsWith('Bearer ')) return new Response(JSON.stringify({error:'No autorizado'}),{status:401,headers:{...corsHeaders,'Content-Type':'application/json'}});
  const url=Deno.env.get('SUPABASE_URL')!, anon=Deno.env.get('SUPABASE_ANON_KEY')!, service=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const caller=createClient(url,anon,{global:{headers:{Authorization:authHeader}}});
  const {data:{user},error:authErr}=await caller.auth.getUser();
  if(authErr||!user) return new Response(JSON.stringify({error:'Sesión inválida'}),{status:401,headers:{...corsHeaders,'Content-Type':'application/json'}});
  const admin=createClient(url,service,{auth:{autoRefreshToken:false,persistSession:false}});
  const {data:actor}=await admin.from('profiles').select('rank,active').eq('id',user.id).maybeSingle();
  if(!actor?.active||!['superadmin','admin'].includes(actor.rank)) return new Response(JSON.stringify({error:'Solo un administrador activo puede crear cuentas'}),{status:403,headers:{...corsHeaders,'Content-Type':'application/json'}});
  const body=await req.json(); const username=String(body.username??'').trim();const email=String(body.email??'').trim().toLowerCase();const password=String(body.password??'');const rank=String(body.rank??'soldado');
  if(username.length<2||username.length>32||!/^[\p{L}\p{N}_. -]+$/u.test(username)) throw new Error('Nombre de agente no válido.');
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Correo electrónico no válido.');
  if(password.length<12) throw new Error('La contraseña inicial debe tener al menos 12 caracteres.');
  if(!allowedRanks.includes(rank)) throw new Error('Rango no válido.');
  if(rank==='superadmin'&&actor.rank!=='superadmin') return new Response(JSON.stringify({error:'Solo un superadmin puede crear otro superadmin'}),{status:403,headers:{...corsHeaders,'Content-Type':'application/json'}});
  const {data:created,error:createErr}=await admin.auth.admin.createUser({email,password,email_confirm:true,user_metadata:{username}});
  if(createErr) throw createErr;
  const {error:profileErr}=await admin.from('profiles').insert({id:created.user.id,username,rank,active:true});
  if(profileErr){await admin.auth.admin.deleteUser(created.user.id);throw profileErr;}
  await admin.from('activity_logs').insert({actor_id:user.id,action:`Cuenta creada: ${username} (${rank})`});
  return new Response(JSON.stringify({ok:true}),{status:200,headers:{...corsHeaders,'Content-Type':'application/json'}});
 } catch(e) { return new Response(JSON.stringify({error:e instanceof Error?e.message:'Error interno'}),{status:400,headers:{...corsHeaders,'Content-Type':'application/json'}}); }
});
